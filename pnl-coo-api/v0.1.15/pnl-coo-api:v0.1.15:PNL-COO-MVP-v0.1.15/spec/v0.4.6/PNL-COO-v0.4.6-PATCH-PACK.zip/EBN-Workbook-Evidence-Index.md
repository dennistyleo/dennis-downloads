# Private Demo Workbook Scan (EBN 2017/08) — Quick Evidence Index

## Sheets detected
- 兩期比較
- 2017 預算
- Summary
- TWN_BS
- TWN_IS
- ＴＷＮ_IS_v
- TWN_IS-調整存貨跌價
- 功能別IS
- TWN_費用明細
- 現金流量表
- 現金流量表_v
- 現金流量表 (底稿)
- Inventory+AR Aging
- 毛利率分析與調整
- 客戶毛利排行
- TWN_前十大客戶
- 利潤by區域機種
- 產品別毛利表
- 產品別毛利表-未扣製費分攤
- MVA by 區域機種
- 客戶MVA
- 週轉天數趨勢圖
- 週轉天趨勢圖_v
- Customer Map
- 比率分析
- BS明細
- BS
- IS明細
- 製造費用明細
- 銷售費用
- 管理費用
- 研發費用
- 海關三旬匯率

## Keyword hits (sheet, keyword)

